ForenQuest - Deleted Files Practice Dataset

This is a synthetic training dataset.

Scenario:
An employee allegedly deleted important documents.

Examine the records to identify deleted files.

All information is fictional.