ForenQuest - Hex Investigation Practice Dataset

This is a synthetic training dataset.

Scenario:
Some files have incorrect extensions.

Compare their reported extensions with
their hexadecimal file signatures.