ForenQuest - USB Investigation Practice Dataset

This is a synthetic training dataset.

Scenario:
A confidential file may have been copied
to an external USB device.

Examine the mock Windows artifacts.