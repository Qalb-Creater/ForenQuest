ForenQuest - Hidden Evidence Practice Dataset

This is a synthetic training dataset.

Scenario:
Investigators suspect that a user concealed
important files on a computer.

Examine the provided records.